import React from 'react'
class Birds extends React.Component
 {
    state = {  }
    render() { 
        return (<h2>Welcome to birds class</h2>);
    }
}
 
export default Birds;