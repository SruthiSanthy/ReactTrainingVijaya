import React from 'react'
class Employees extends React.Component
 {
    render() { 
        return (<h2>Welcome to employees class</h2>);
    }
}
 
export default Employees;