import React from 'react'
class Users extends React.Component
 {
    render() { 
        return (<h2>Welcome to users class</h2>);
    }
}
 
export default Users;