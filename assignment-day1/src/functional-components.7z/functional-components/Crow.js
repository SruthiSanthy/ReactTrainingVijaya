import React from 'react'

const Crow = () =>
{
    return (<div><h3>Crow</h3><p>Crow is black</p></div>)
}

export default Crow