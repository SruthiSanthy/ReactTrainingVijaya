import React from 'react'

const Hen = () =>
{
    return (<div><h1>Hen</h1><p>Hen lays eggs</p></div>)
}

export default Hen