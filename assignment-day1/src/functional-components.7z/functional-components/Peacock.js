import React from 'react'

const Peacock = () =>
{
    return (<div><h3>Peacock</h3><p>Peacock is very beautifull</p></div>)
}

export default Peacock