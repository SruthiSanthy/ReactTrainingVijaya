import React from 'react'

const Parrot = () =>
{
    return (<div><h3>Parrot</h3><p>Parrot is green</p></div>)
}

export default Parrot