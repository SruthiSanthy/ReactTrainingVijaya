import React from 'react'

const Pigeon = () =>
{
    return (<div><h3>Pigeon</h3><p>Pigeon is white</p></div>)
}

export default Pigeon