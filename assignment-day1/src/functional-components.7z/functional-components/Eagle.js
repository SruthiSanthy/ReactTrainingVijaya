import React from 'react'

const Eagle = () =>
{
    return (<div><h3>Eagle</h3><p>Eagle is a big bird</p></div>)
}

export default Eagle