import React from 'react'

class Lion extends React.Component
{
    render()
    {
        return(<><h3>Lion</h3><p>Lion is the king of forest</p></>)
    }
}
export default Lion