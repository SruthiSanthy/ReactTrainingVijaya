import React from 'react'

class Tiger extends React.Component
{
    render()
    {
        return(<div><h3>Tiger</h3><p>Tiger is very powerful</p></div>)
    }
}
export default Tiger