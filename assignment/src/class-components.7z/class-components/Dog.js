import React from 'react'

class Dog extends React.Component
{
    render()
    {
        return(<div><h3>Dog</h3><p>Dogs are human's friend</p></div>)
    }
}
export default Dog