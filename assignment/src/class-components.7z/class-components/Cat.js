import React from 'react'

class Cat extends React.Component
{
    render()
    {
        return(<div><h3>Cat</h3><p>Cats are very cute</p></div>)
    }
}
export default Cat